#include <iostream>
#include <string>
using namespace std;

class Date
{
	friend ostream& operator <<(ostream& os, const Date& d);
private:
	int year, month, day;
public:
	Date (int y = 0, int m = 0, int d = 0) : year(y),month(m),day(d) { }
	Date & operator++()
	{
			if (month == 12 && day == 31)
			{
				year = year + 1;
				day = 1;
				month = 1;
			}
			else if (month == 4,6,9,11 && day == 30)
			{
				day = 1;
				month = month + 1;
			}
			else if (month == 2 && day == 28)
			{
				day = 1;
				month = month + 1;
			}
			else if (month == 1, 3, 5, 7, 8, 10 && day == 31)
			{
				day = 1;
				month = month + 1;
			}
			else
				day = day + 1;
		return *this;
	}
	Date & operator--()
	{ 
		
		if (day == 1)
		{
			if (month == 1)
			{
				day = 31;
				month = 12;
				year = year - 1;
			}
			else if (month ==2,4,6,8,9,11 )
			{
				month = month - 1;
				day = 31;
			}
			else if (month ==5,7,10,12 )
			{
				month = month - 1;
				day = 30;
			}
			else
			{
				month = month - 1;
				day = 28;
			}
		}
		else
			day = day - 1;
		return *this;
	}
	
};
ostream& operator <<(ostream& os, const Date& d)
{
	os << d.year << "��" << d.month << "��" << d.day << "��" << endl;
	return os;
}
int main()
{
	Date d1(1987, 4, 27);
	Date d2(2018, 11, 14);
	Date d3(2011, 1, 1);
	Date d4(1999, 12, 31);
	cout << d1;
	cout << ++d2;
	cout << --d3;
	cout << ++d4;

	return 0;
}