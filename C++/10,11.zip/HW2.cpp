#include <iostream>
#include <string>
using namespace std;

class ProcessScore
{
private:
	int score[5];
	int number;
	double avg;
public:
	ProcessScore(int s[5], int n) : score(),number(n) { }
	void display();
};
void ProcessScore::display()
	{
		int i;
		for (i = 0; i < 5; i++)
		{
			if (score[i] < 0)
				throw "IllegalscoreException";
		}
		avg = (score[0] + score[1] + score[2] + score[3] + score[4]) / 5;
		cout << "��� : " << avg << endl;
	}
int main()
{
	int score[5] = { 10,20,30,-40,50 };
	try
	{
		int i;
		double avg;
		ProcessScore p(score, 5);
		for (i = 0; i < 5; i++)
		{
			if (score[i] < 0)
				throw "IllegalscoreException";
		}
		avg = (score[0] + score[1] + score[2] + score[3] + score[4]) / 5;
		cout << "��� : " << avg << endl;
		p.display();
	}
	catch (const char *e)
	{
		cout << e << endl;
	}
	return 0;
}