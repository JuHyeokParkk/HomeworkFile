#include <iostream>
#include <string>
using namespace std;

class Person {
private:
	string name;
	string address;
	string phone;

public:
	Person(string n = "", string a = "", string p = "") : name(n), address(a), phone(p) {}
	void setName(string n) { name = n; }
	string getName() { return name; }
	void setAddress(string a) { address = a; }
	string getAddress() { return address; }
	void setPhone(string p) { phone = p; }
	string getPhone() { return phone; }
};

class Customer : public Person {
private:
	string number;
	int mi;

public:
	Customer(string n = "", string a = "", string p = "", string num = "", int m = 0) : Person(n, a, p), number(num), mi(m) { }
	void setNumber(string num) { number = num; }
	string getNumber() { return number; }
	void setMi(int m) { mi = m; }
	int getMi() { return mi; }
	void Print();
};

void Customer::Print()
{
	cout << "��    �� : " << this->getName() << endl;
	cout << "��    �� : " << this->getAddress() << endl;
	cout << "��ȭ��ȣ : " << this->getPhone() << endl;
	cout << "������ȣ : " << this->getNumber() << endl;
	cout << "���ϸ��� : " << this->getMi() << endl;
	cout << endl;
}

int main()
{
	Customer c1("��ö��", "�������б� �������� 6ȣ��", "01012345678", "135246", 35000);
	Customer c2("�ڿ���", "�������б� �������� 7ȣ��", "01078945612", "142512", 17500);

	c1.Print();
	c2.Print();

	return 0;
}