#include <iostream>
#include <string>
using namespace std;

class Shape
{
protected:
	string name;
	int x, y;
public:
	Shape(string n = "") : name(n) {}
	virtual double getSurfaceArea() //3���� ǥ�������
	{
		return x * y;
	}
	virtual void  Print() //�̸� ǥ�������
	{
		cout << name << endl;
		cout << "�ѳ��� : " << getSurfaceArea() << endl;
		cout << "=========================" << endl;
	}
};
class Sphere : public Shape //��
{
private:
	int rad;
public:
	Sphere(string n = "", int r = 0) : Shape(n), rad(r) {}
	double getSurfaceArea()
	{
		return 4 * 3.141592 * rad * rad;
	}
	void Print()
	{
		cout << name << endl;
		cout << "�ѳ��� : " << getSurfaceArea() << endl;
		cout << "=========================" << endl;
	}
};

class Cube : public Shape //������ü
{
private:
	int width, length, height;
public:
	Cube(int w = 0, int l = 0, int h = 0, string n = "") : width(w), length(l), height(h), Shape(n) {}
	double getSurfaceArea()
	{
		return 2 * (width*length + length * height + height * width);
	}
	void Print()
	{
		cout << name << endl;
		cout << "�ѳ��� : " << getSurfaceArea() << endl;
		cout << "=========================" << endl;
	}
};

class Cylinder : public Shape //�����
{
	int rad, height;
public:
	Cylinder(int h = 0, int r = 0, string n = "") : height(h), rad(r), Shape(n) {}
	double getSurfaceArea()
	{
		return 2 * 3.141592 * rad * (rad + height);
	}
	void Print()
	{
		cout << name << endl;
		cout << "�ѳ��� : " << getSurfaceArea() << endl;
		cout << "=========================" << endl;
	}
};

int main()
{
	Shape *arrayOfShapes[3];

	arrayOfShapes[0] = new Sphere("Sphere", 3);
	arrayOfShapes[1] = new Cube(4, 5, 6, "Cube");
	arrayOfShapes[2] = new Cylinder(7, 3, "Cylinder");

	for (int i = 0; i < 3; i++)
	{
		arrayOfShapes[i]->Print();
	}

	return 0;
}