//172598 ������ cpp Chapter 9 5�� �ҽ��ڵ�

#include <iostream>

using namespace std;

class Shape {
public:
	virtual void print() = 0;

};

class TwoDimShape : public Shape {
public:
	virtual void getArea() = 0;
};

class Ellipse : public TwoDimShape {
	int area;
public:
	void getArea()
	{
		area = 10;
	}

	void print()
	{
		cout << "���� : " << area << endl;
	}
};

class Rectangle : public TwoDimShape {
	int area;
public:
	void getArea()
	{
		area = 15;
	}

	void print()
	{
		cout << "���� : " << area << endl;
	}
};

class Triangle : public TwoDimShape {
	int area;

	void getArea()
	{
		area = 25;
	}

	void print()
	{
		cout << "���� : " << area << endl;
	}
};

class ThreeDimShape : public Shape {
public:
	virtual void getVolume() = 0;
};

class Shpere : public ThreeDimShape {
	double volume;
public:
	void getVolume()
	{
		volume = 12.2;
	}

	void print()
	{
		cout << "���� : " << volume << endl;
	}
};

class Cube : public ThreeDimShape {
	double volume;
public:
	void getVolume()
	{
		volume = 13.5;
	}

	void print()
	{
		cout << "���� : " << volume << endl;
	}
};

class Cylinder : public ThreeDimShape {
	double volume;

	void getVolume()
	{
		volume = 14.4;
	}

	void print()
	{
		cout << "���� : " << volume << endl;
	}
};

int main()
{
	Shape* arr[6];
	arr[0] = new Ellipse;
	arr[1] = new Rectangle;
	arr[2] = new Triangle;
	arr[3] = new Shpere;
	arr[4] = new Cube;
	arr[5] = new Cylinder;

	for (int i = 0; i < 3; i++)
	{
		((TwoDimShape*)arr[i])->getArea();
		arr[i]->print();
	}

	for (int i = 3; i < 6; i++)
	{
		((ThreeDimShape *)arr[i])->getVolume();
		arr[i]->print();
	}
}