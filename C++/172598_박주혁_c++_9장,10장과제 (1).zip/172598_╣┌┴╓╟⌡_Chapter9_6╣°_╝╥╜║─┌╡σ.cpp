//172598 ������ cpp Chapter 9 6�� �ҽ��ڵ�

#include <iostream>
#include <string>

using namespace std;

class Shape {
private:
	string name;

public:
	virtual void getSurfaceArea() = 0;
	virtual void set() = 0;
};

class Sphere : public Shape {
private:
	int radius;

public:
	
	void set()
	{
		radius = 3;
	}
	void getSurfaceArea()
	{
		cout << (double)4 / 3 * 3.14 * radius * radius * radius << endl;
	}
};

class Cube : public Shape {
private:
	int width;
	int high;
	int height;

public:

	void set()
	{
		width = 1;
		high = 2;
		height = 3;
	}
	
	void getSurfaceArea()
	{
		cout << (double)width * high * height << endl;
	}
};

class Cylinder : public Shape {
private:
	int radius;
	int height;

public:
	void set()
	{
		radius = 4;
		height = 5;
	}
	void getSurfaceArea()
	{
		cout << 3.14 * radius * radius * height << endl;
	}
};

int main()
{
	Shape* arr[3];
	arr[0] = new Sphere;
	arr[1] = new Cube;
	arr[2] = new Cylinder;

	
	for (int i = 0; i < 3; i++)
	{
		arr[i]->set();
		arr[i]->getSurfaceArea();
	}

	return 0;
}