//172598 ������ cpp Chapter 10 6�� �ҽ��ڵ�

#include <iostream>
#define MAX_SIZE 100

using namespace std;

class Set {
private:
	int arr[MAX_SIZE];
	int size;

	friend ostream& operator<<(ostream& os, Set& b);
	friend istream& operator>>(istream& is, Set& b);

public:
	Set() : size(0) {}

	bool Search(const int value) const;
	Set operator+(const int value);
	Set operator-(const int value);
	Set operator|(Set b);
	Set operator&(Set b);
	bool operator==(Set b);
	

	void print_arr() const;
};

int main()
{

}

bool Set::Search(const int value) const
{
	for (int i = 0; i < this->size; i++)
	{
		if (this->arr[i] == value)
			return true;
	}

	return false;
}

Set Set::operator+(const int value)
{
	if (!Search(value))
		this->arr[this->size++] = value;

	return *this;
}

Set Set::operator-(const int value)
{
	
	for (int i = 0; i < this->size; i++)
	{
		if (this->arr[i] == value)
		{
			
				for (int j = this->size - 1; j != 0 && j >= i; j--)
				{
					this->arr[j - 1] = this->arr[j];
				}
			
			this->size--;
			return (*this);
		}
	}
	return (*this);
}

Set Set::operator|(Set b)
{
	Set c = *this;

	for (int i = 0; i < b.size; i++)
	{
		if (!Search(b.arr[i]))
			c + b.arr[i];
	}
	return c;
}

Set Set::operator&(Set b)
{
	Set c;
	for (int i = 0; i < b.size; i++)
	{
		if (Search(b.arr[i]))
			c + b.arr[i];
	}

	return c;
}

bool Set::operator==(Set b)
{
	if (this->size != b.size)
		return false;

	for (int i = 0; i < this->size; i++)
	{
		if (!Search(b.arr[i]))
			return false;
	}

	return true;
}

ostream& operator<<(ostream& os, Set &b) 
{
	for (int i = 0; i < b.size; i++)
	{
		os << b.arr[i];
	}
	return os;
}

istream& operator>>(istream& is, Set& b)
{
	is >> b.size;
	for (int i = 0; i < b.size; i++)
		is >> b.arr[i];

	return is;
}
void Set::print_arr() const
{
	for (int i = 0; i < this->size; i++)
		cout << arr[i] << " ";
	cout << endl;
}

