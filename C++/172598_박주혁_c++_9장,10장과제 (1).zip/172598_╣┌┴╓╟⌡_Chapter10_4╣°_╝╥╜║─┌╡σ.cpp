//172598 ������ Chapter 10 4�� �ҽ��ڵ�

#include <iostream>

using namespace std;

class Time {
private:
	int hour;
	int minute;
	int second;

public:
	Time() : hour(0), minute(0), second(0) {}
	Time(int h, int m, int s) : hour(h), minute(m), second(s) {}

	Time operator+(int second);
	Time operator-(int second);
	bool operator<(Time& t) const;
	bool operator>(Time& t) const;
	bool operator==(Time& t) const;
	bool operator!=(Time& t) const;
	friend ostream& operator<< (ostream& os, Time& t);
	friend istream& operator>> (istream& is, Time& t);

};

int main()
{
	Time start;
	Time end = start + 1000; // 1000�� ��
	Time m = end - 500;
	
	cout << end;
	cout << m;

	
}
Time Time::operator+(int second)
{
	Time t;
	t.hour = this->hour + second / 3600;
	second %= 3600;

	t.minute = this->minute + second / 60;
	if (t.minute >= 60)
	{
		t.hour++;
		t.minute -= 60;
	}
	second %= 60;

	t.second = this->second + second;
	if (t.second >= 60)
	{
		t.minute++;
		t.second -= 60;
	}

	return t;
}

Time Time::operator-(int second)
{
	Time t;
	t.hour = this->hour - second / 3600;
	second %= 3600;

	t.minute = this->minute - second / 60;
	if (t.minute < 0)
	{
		t.hour--;
		t.minute = 60 + t.minute;
	}
	second %= 60;

	t.second = this->second - second;
	if (t.second < 0)
	{
		t.minute--;
		t.second = 60 + t.second;
	}

	return t;
}

bool Time::operator<(Time& t) const
{
	if (this->hour < t.hour) return 1;
	if (this->hour > t.hour) return 0;

	if (this->minute < t.minute) return 1;
	if (this->minute > t.minute) return 0;

	if (this->second < t.second) return 1;
	return 0;
}

bool Time::operator>(Time& t) const
{
	return !((*this) < t);
}

bool Time::operator==(Time& t) const
{
	return this->hour == t.hour && this->minute == t.minute && this->second == t.second;
}

bool Time::operator!=(Time& t) const
{
	return !((*this) == t);
}

ostream& operator<<(ostream& os, Time& t)
{
	os << "hour : " << t.hour << " minute : " << t.minute << " second : " << t.second << endl;
	return os;
}

istream& operator>>(istream& is, Time& t)
{
	is >> t.hour >> t.minute >> t.second;
	if (!is)
		t = Time(0, 0, 0);
	return is;
}