#include <iostream>
#include <string>
using namespace std;

int main(void)
{
	string number;
	cout << "��ȭ��ȣ�� �Է��Ͻÿ�: ";
	cin >> number;
	int A[20] = { 0 };
	int a = 0;
	cout << "-�� ���ŵ� ��ȭ��ȣ: ";


	for (int i = 0; i < number.length(); i++)
	{	
		
		if (number.find("-")!= string::npos)
		{
			a++;
			A[i] = number.find("-");
			number.erase(A[i],1);
			
			continue;
		}
	}
	cout << number;
	cout << endl;

	return 0;
}