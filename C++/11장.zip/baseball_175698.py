import random

a=0;
strike=0;
out =0;
ball=0;

while 1:
    start = input("Play game ? <y/n> : ");
    number = [[0]*3 for i in range(3)]

    number[0] = str(random.randrange(1, 9, 1))
    number[1] = number[0]
    number[2] = number[0]
    while (number[0] == number[1]):
        number[1] = str(random.randrange(1, 9, 1))
    while (number[0] == number[2] or number[1] == number[2]):
        number[2] = str(random.randrange(1, 9, 1))

    print(number);

    if start=="y":
        for i in range (9):
                a +=1;
                print("***BASEBALL GAME .... ROUND : %d"%(i+1))
                user = str(input("USER : "));
                for i in range (3):
                    for j in range (3):
                        if(user[i]==str(number[j]) and i==j):
                            strike +=1;
                        elif(user[i]==str(number[j]) and i!=j):
                            ball +=1;
                        else:
                            out +=1;    

                if(strike!=0 and ball!=0):
                    print("COMPUTER : %d STRIKE, %d BALL !!!!"%(strike,ball));
                elif(strike!=0):
                    print("COMPUTER : %d STRIKE !!!!"%strike);
                elif(ball!=0):
                    print("COMPUTER : %d BALL !!!!"%ball);
                elif(strike==0 and ball==0 and out!=0):
                    print("COMPUTER : O U T !!!!");
                if(strike==3):
                    print("\nUSER WINNER !!!!\n");
                    break;
                if(a==9 and strike!=3):
                    print("\nCOMPUTER WINNER !!!!\n")
                    print("The numbers are ", end = ' ')
                    for i in range(3):
                        print(number[i], end = ' ')
                    print("\n");
                strike = 0;
                ball = 0;
                out = 0;
    else:
        break;

        

