import math
number = int(input("값을 입력하세요 : "))


a = int(math.sqrt(number));
b = math.sqrt(number);

arr = []
for i in range(number):
    arr.append([-1]*number);
x=0;
y=0;
dx,dy = 0,1;
count = 1;
while arr[x][y] == -1:
    arr[x][y] = count
    count+=1
    
    if count>number+1:
        arr[x][y] = 0;
    x,y = x+dx,y+dy

    if b%1==0:
        if x in [-1,a]  or y in [-1,a] or arr[x][y]!=-1:
            x,y = x-dx, y-dy
            dx,dy = dy,-dx
            x,y = x+dx,y+dy
    else:
        if x in [-1,a+1]  or y in [-1,a+1] or arr[x][y]!=-1:
            x,y = x-dx, y-dy
            dx,dy = dy,-dx
            x,y = x+dx,y+dy

if b%1==0:
    for i in range(0,a):
        for j in range(0,a):
            print("%4d" %arr[i][j], end = " ");
        print();
else:
    for i in range(0,a+1):
        for j in range(0,a+1):
            print("%4d" %arr[i][j], end = " ");
        print();
