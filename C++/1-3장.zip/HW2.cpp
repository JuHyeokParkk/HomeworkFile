#include <iostream>
using namespace std;
void MySort(int* arr, int n);
void MySwap(int& a, int& b);

int main(void)
{
	int arr[5] = { 7,3,6,2,4 };
	int i;
	MySort(arr,5);
	for (i = 0; i < 5; i++)
		cout << arr[i] << " ";
	cout << endl;

}
void MySort(int* arr, int n)
{
	int i;
	for (i = n-2; i >=0; --i)
	{
		for (int j = 0; j <= i; ++j)
		{
			if (arr[j] > arr[j + 1])
				MySwap(arr[j], arr[j+1]);
		}
	}
}
void MySwap(int& a, int& b)
{
	int temp;
	temp = a;
	a = b;
	b = temp;
}