#include  <iostream>
using namespace std;

int factorial(int n)
{
	if (n <= 1)
		return 1;
	else
		return n * factorial(n - 1);
}
double factorial(double n)
{
	cout << "������ ����ϼ���." << endl;
	cout << n << "! : " << n << endl;

	return n;
}
int main(void)
{
	int F;
	F = factorial(5);
	cout << 5 << "! : " << F << endl;
	factorial(5.7);
}
