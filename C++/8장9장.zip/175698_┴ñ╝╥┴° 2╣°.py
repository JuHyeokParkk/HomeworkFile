n = int(input("n을 입력하세요 : "))
print("%d개의 숫자를 입력하세요 :"%n)

number = [[0]*n for i in range(n)]
for i in range(n):
    m = int(input())
    number[i] = m

number.sort()

if(n%2==1):
    print ("중간값은 %d입니다."%number[int(n/2)])
else:
    print ("중간값은 %3.1f입니다."%((number[int(n/2)-1]+number[int(n/2)])/2))



