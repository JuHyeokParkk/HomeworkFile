score1 = int(input("점수를 입력하세요 : "))
score2 = int(input("점수를 입력하세요 : "))
score3 = int(input("점수를 입력하세요 : "))

min = score1
if min > score2 :
    min = score2
if min > score3 :
    min = score3

average = (score1+score2+score3-min)/2
if average%1==0:
    average = int((score1+score2+score3-min)/2)
    
print("평균은 : "+str(average))
