string = input("문자열 입력 :")
new = ""
print(string)
number = int(len(string))

for i in range(number):
    if string[i] != "r":
        new += string[i]

print(new)
