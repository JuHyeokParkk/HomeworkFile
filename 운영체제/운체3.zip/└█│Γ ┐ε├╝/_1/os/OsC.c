#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<Windows.h>
#include<tchar.h>
#include<stdlib.h>
#include<time.h>


int main()
{
	int sum=0;
	int num1, num2, num3, num4;
	int rt;
	
	//������ �����̸�.
	TCHAR childA[] = _T("OsA.exe");
	TCHAR childB[] = _T("OsB.exe");

	STARTUPINFO si1;
	PROCESS_INFORMATION pi1;

	STARTUPINFO si2;
	PROCESS_INFORMATION pi2;

	//�޸��Ҵ�
	ZeroMemory(&si1, sizeof(si1));
	si1.cb = sizeof(si1);
	ZeroMemory(&pi1, sizeof(pi1));

	ZeroMemory(&si2, sizeof(si2));
	si2.cb = sizeof(si2);
	ZeroMemory(&pi2, sizeof(pi2));

	//���μ��� ����
	if(!CreateProcess(NULL, childA , NULL, NULL, FALSE, 0, NULL, NULL, &si1, &pi1))
	{
		printf("Create Process Failed");
		return -1;
	}
	else
	{
		printf("Process Child A PID : %d \n", pi1.dwProcessId);	//�ڽ����μ����� pid
		fflush(stdin);
	}
				
	//���μ��� ����
	if(!CreateProcess(NULL, childB , NULL, NULL, FALSE, 0, NULL, NULL, &si2, &pi2))
	{
		printf("Create Process Failed");
		return -1;
	}
	else
	{
		printf("Process Child B PID : %d \n", pi2.dwProcessId);	//�ڽ����μ����� pid
		fflush(stdin);
	}
	
	WaitForSingleObject(pi1.hProcess, INFINITE);
	
	CloseHandle(pi1.hProcess);
	CloseHandle(pi1.hThread);

	WaitForSingleObject(pi2.hProcess, INFINITE);

	CloseHandle(pi2.hProcess);
	CloseHandle(pi2.hThread);

	srand((unsigned)time(NULL));
	rt = rand()%3 + 1;

	scanf("%d", &num1);		
	Sleep(rt*1000);
	scanf("%d", &num2);
	Sleep(rt*1000);	
	scanf("%d", &num3);
	Sleep(rt*1000);	
	scanf("%d", &num4);
	Sleep(rt*1000);

	sum = (num1 + num2 + num3 + num4);
	
	//GetCurrentProcessId() �ڱ��ڽ��� pid
	printf("\nPID : %d, num1 : %d, num2 : %d, num3 : %d, num4 : %d, sum : %d \n", GetCurrentProcessId(), num1, num2, num3, num4, sum);
	


	return 0;
}