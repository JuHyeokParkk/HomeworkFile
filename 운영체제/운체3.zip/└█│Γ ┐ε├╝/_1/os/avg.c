#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<Windows.h>
#include<stdlib.h>
#include<time.h>

int main()
{
	double avg=0;
	int num1, num2, num3, num4;
	int rt;
	srand((unsigned)time(NULL));

	rt = rand()%3 + 1;
	
	scanf("%d", &num1);		
	Sleep(rt*1000);
	scanf("%d", &num2);
	Sleep(rt*1000);	
	scanf("%d", &num3);
	Sleep(rt*1000);	
	scanf("%d", &num4);
	Sleep(rt*1000);

	avg = (num1 + num2 + num3 + num4) / (double)4;
	
	printf("PID : %d, num1 : %d, num2 : %d, num3 : %d, num4 : %d, avg : %.2lf \n", GetCurrentProcessId(), num1, num2, num3, num4, avg);

	return 0;
}