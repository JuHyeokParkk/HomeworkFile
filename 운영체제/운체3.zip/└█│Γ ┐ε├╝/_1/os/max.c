#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<Windows.h>
#include<stdlib.h>
#include<time.h>


int main()
{
	int max=0;
	int num1, num2, num3, num4;
	int rt=0;
	srand((unsigned)time(NULL));

	rt = rand()%3 + 1;
	
	scanf("%d", &num1);		
	Sleep(rt*1000);
	scanf("%d", &num2);
	Sleep(rt*1000);	
	scanf("%d", &num3);
	Sleep(rt*1000);	
	scanf("%d", &num4);
	Sleep(rt*1000);

	max = num1;

	if(max<num2)
	{
		max = num2;
	}
	if(max<num3)
	{
		max = num3;
	}
	if(max<num4)
	{
		max = num4;
	}

	printf("PID : %d, num1 : %d, num2 : %d, num3 : %d, num4 : %d, max : %d \n", GetCurrentProcessId(), num1, num2, num3, num4, max);

	return 0;
}
	