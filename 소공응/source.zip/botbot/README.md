전남대학교 컴퓨터정보통신공학전공
172598 박주혁, 175739 한재현

Goorm IDE 환경에서 가능한 소스코드입니다.

Selenium 설치
pip3 install selenium

Chrome 설치
wget -q -O - https://dl-ssl.google.com/linux/linux_signing_key.pub | apt-key add -
echo 'deb [arch=amd64] http://dl.google.com/linux/chrome/deb/ stable main' | tee /etc/apt/sources.list.d/google-chrome.list
apt-get update
apt-get install -y google-chrome-stable

현재 설치된 Chrome의 버전 확인
google-chrome --version

ChromeDriver 다운로드
wget -N https://chromedriver.storage.googleapis.com/[크롬 드라이버 버전]/chromedriver_linux64.zip

ChromeDriver 설치
unzip chromedriver_linux64.zip
chmod +x chromedriver
mv -f chromedriver /usr/local/share/chromedriver
ln -s /usr/local/share/chromedriver /usr/local/bin/chromedriver
ln -s /usr/local/share/chromedriver /usr/bin/chromedriver
rm chromedriver_linux64.zip
apt-get update
apt-get install -y libgconf-2-4

Selenium 설정 코드 예시
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

options = Options()
options.add_argument("--headless")
options.add_argument("--no-sandbox")
options.add_argument('disable-gpu')
options.add_argument('--disable-dev-shm-usage')
options.add_argument('--no-sandbox')
options.add_argument('--ignore-certificate-errors')
driver = webdriver.Chrome(options=options)
driver.get('https://google.com')
driver.quit()

감사합니다.